import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import PublicNavbar from './PublicNavbar'
import PublicFooter from './PublicFooter'

export default function PublicLayout() {
  const location = useLocation()

  useEffect(() => {
    if (!location.hash) return
    const id = location.hash.slice(1)
    requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView({ behavior: 'auto', block: 'start' }))
  }, [location.pathname, location.hash])

  return (
    <div className="min-h-screen bg-base">
      <PublicNavbar />
      <div className="flex min-h-screen flex-col lg:pl-72">
        <main className="flex-1"><Outlet /></main>
        <PublicFooter />
      </div>
    </div>
  )
}
