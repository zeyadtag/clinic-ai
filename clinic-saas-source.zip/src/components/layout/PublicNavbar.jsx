import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Cross, Menu, X } from 'lucide-react'
import { useClinicData } from '../../context/DataContext'

const links = [
  { to: '/', label: 'Home', end: true },
  { to: '/#services', label: 'Services' },
  { to: '/#about', label: 'About' },
  { to: '/#reviews', label: 'Reviews' },
]

export default function PublicNavbar() {
  const { clinic } = useClinicData()
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-white">
            <Cross className="h-4 w-4" />
          </span>
          <span className="font-display text-lg text-ink">{clinic.name}</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <NavLink key={l.label} to={l.to} end={l.end} className="text-sm text-ink/70 hover:text-ink">
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Link to="/portal" className="text-sm text-ink/70 hover:text-ink">Patient access</Link>
          <Link to="/book" className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-dark">
            Book Appointment
          </Link>
        </div>

        <button className="md:hidden" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-line px-5 pb-4 md:hidden">
          <nav className="flex flex-col gap-3 pt-3">
            {links.map((l) => (
              <NavLink key={l.label} to={l.to} onClick={() => setOpen(false)} className="text-sm text-ink/70">
                {l.label}
              </NavLink>
            ))}
            <Link to="/portal" onClick={() => setOpen(false)} className="text-sm text-ink/70">Patient access</Link>
            <Link to="/book" onClick={() => setOpen(false)} className="rounded-md bg-primary px-4 py-2 text-center text-sm font-medium text-white">
              Book Appointment
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
