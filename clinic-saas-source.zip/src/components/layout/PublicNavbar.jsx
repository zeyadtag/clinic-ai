import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Cross, LayoutDashboard, Menu, X } from 'lucide-react'
import { useClinicData } from '../../context/DataContext'

const links = [
  { to: '/', label: 'Home', end: true },
  { to: '/#services', label: 'Services' },
  { to: '/#about', label: 'About' },
  { to: '/#reviews', label: 'Reviews' },
]

export default function PublicNavbar() {
  const { clinic } = useClinicData()
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-white">
            <Cross className="h-4 w-4" />
          </span>
          <span className="font-display text-lg text-ink">{clinic.name}</span>
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <NavLink key={l.label} to={l.to} end={l.end} className="text-sm text-ink/70 hover:text-ink">
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Link to="/dashboard" className="inline-flex items-center gap-2 rounded-md border border-line px-3.5 py-2 text-sm font-medium text-ink hover:border-primary/40 hover:bg-primary-light/50">
            <LayoutDashboard className="h-4 w-4 text-primary" /> Doctor Dashboard
          </Link>
          <Link to="/portal" className="text-sm text-ink/70 hover:text-ink">Patient access</Link>
          <Link to="/book" className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-dark">
            Book Appointment
          </Link>
        </div>

        <button className="rounded-md border border-line p-2 lg:hidden" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 top-[72px] z-50 bg-ink/25 lg:hidden" onClick={() => setOpen(false)}>
          <nav className="ml-auto flex h-full w-[82%] max-w-sm flex-col gap-2 border-l border-line bg-paper p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            {links.map((l) => (
              <NavLink key={l.label} to={l.to} onClick={() => setOpen(false)} className="rounded-md px-3 py-3 text-sm font-medium text-ink/70 hover:bg-base">
                {l.label}
              </NavLink>
            ))}
            <div className="my-2 border-t border-line" />
            <Link to="/dashboard" onClick={() => setOpen(false)} className="flex items-center gap-2 rounded-md bg-primary-light px-3 py-3 text-sm font-semibold text-primary-dark">
              <LayoutDashboard className="h-4 w-4" /> Doctor Dashboard
            </Link>
            <Link to="/portal" onClick={() => setOpen(false)} className="rounded-md px-3 py-3 text-sm text-ink/70">Patient access</Link>
            <Link to="/book" onClick={() => setOpen(false)} className="mt-1 rounded-md bg-primary px-4 py-3 text-center text-sm font-medium text-white">
              Book Appointment
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
