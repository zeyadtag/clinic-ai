import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { CheckCircle2, Clock3 } from 'lucide-react'
import { useClinicData } from '../../context/DataContext'
import { formatDateTime } from '../../utils/dateHelpers'
import Button from '../ui/Button'
import Card from '../ui/Card'
import VoiceInput from '../ui/VoiceInput'

const emptyForm = { fullName: '', phone: '', email: '', serviceId: '', doctorId: '', date: '', time: '', notes: '' }

export default function BookingForm() {
  const { services, doctors, bookAppointment, joinWaitingList, suggestNearestSlots } = useClinicData()
  const [params] = useSearchParams()
  const [form, setForm] = useState(() => ({ ...emptyForm, serviceId: params.get('service') || '' }))
  const [suggestions, setSuggestions] = useState(null) // null = not searched, [] = none but that shouldn't happen, [slots]
  const [confirmed, setConfirmed] = useState(null)
  const [waitlisted, setWaitlisted] = useState(false)
  const [error, setError] = useState('')

  const service = services.find((s) => s.id === form.serviceId)
  const eligibleDoctors = useMemo(() => doctors.filter((d) => d.isActive), [doctors])

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }))

  const requestedDateTime = useMemo(() => {
    if (!form.date || !form.time) return null
    return new Date(`${form.date}T${form.time}`)
  }, [form.date, form.time])

  const canSubmit = form.fullName && form.phone && form.serviceId && form.doctorId && requestedDateTime

  const handleSubmit = (e) => {
    e.preventDefault()
    setError('')
    if (!canSubmit) {
      setError('Please fill in your name, phone, service, doctor, date and time.')
      return
    }
    const result = bookAppointment({
      fullName: form.fullName,
      phone: form.phone,
      email: form.email,
      serviceId: form.serviceId,
      doctorId: form.doctorId,
      startsAt: requestedDateTime.toISOString(),
      notes: form.notes,
    })

    if (result.ok) {
      setConfirmed(result.appointment)
      setSuggestions(null)
      return
    }

    // Requested slot unavailable — suggest the nearest 3 real openings instead
    // of a flat rejection, per the clinic's booking policy.
    const nearby = suggestNearestSlots(form.doctorId, requestedDateTime, service?.durationMinutes || 30, 3)
    setSuggestions(nearby)
  }

  const bookSuggestedSlot = (slot) => {
    const result = bookAppointment({
      fullName: form.fullName,
      phone: form.phone,
      email: form.email,
      serviceId: form.serviceId,
      doctorId: form.doctorId,
      startsAt: slot.toISOString(),
      notes: form.notes,
    })
    if (result.ok) {
      setConfirmed(result.appointment)
      setSuggestions(null)
    }
  }

  const handleWaitlist = () => {
    joinWaitingList({
      fullName: form.fullName,
      phone: form.phone,
      email: form.email,
      serviceId: form.serviceId,
      doctorId: form.doctorId,
      preferredStart: requestedDateTime,
    })
    setWaitlisted(true)
  }

  if (confirmed) {
    return (
      <Card className="mx-auto max-w-lg text-center">
        <CheckCircle2 className="mx-auto h-10 w-10 text-success" />
        <h3 className="mt-3 font-display text-xl text-ink">You're booked</h3>
        <p className="mt-2 text-sm text-ink/70">
          {form.fullName}, your {service?.name} is confirmed for {formatDateTime(confirmed.startsAt)}.
        </p>
        <p className="mt-1 text-xs text-ink/50">A reminder will be sent 24 hours beforehand.</p>
        <Button className="mt-6" onClick={() => { setConfirmed(null); setForm(emptyForm); setWaitlisted(false) }}>
          Book another appointment
        </Button>
      </Card>
    )
  }

  if (waitlisted) {
    return (
      <Card className="mx-auto max-w-lg text-center">
        <Clock3 className="mx-auto h-10 w-10 text-primary" />
        <h3 className="mt-3 font-display text-xl text-ink">You're on the waiting list</h3>
        <p className="mt-2 text-sm text-ink/70">
          We'll reach out the moment a slot with {doctors.find((d) => d.id === form.doctorId)?.fullName} opens up near your preferred time.
        </p>
        <Button className="mt-6" variant="ghost" onClick={() => { setWaitlisted(false); setForm(emptyForm) }}>
          Done
        </Button>
      </Card>
    )
  }

  return (
    <Card className="mx-auto max-w-xl">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name">
            <input value={form.fullName} onChange={update('fullName')} className="input" placeholder="Jane Doe" />
          </Field>
          <Field label="Phone number">
            <input value={form.phone} onChange={update('phone')} className="input" placeholder="555-123-4567" />
          </Field>
        </div>

        <Field label="Email (optional)">
          <input value={form.email} onChange={update('email')} type="email" className="input" placeholder="jane@example.com" />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Service">
            <select value={form.serviceId} onChange={update('serviceId')} className="input">
              <option value="">Select a service</option>
              {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="Doctor">
            <select value={form.doctorId} onChange={update('doctorId')} className="input">
              <option value="">Select a doctor</option>
              {eligibleDoctors.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
            </select>
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Date">
            <input type="date" value={form.date} onChange={update('date')} className="input" min={new Date().toISOString().slice(0, 10)} />
          </Field>
          <Field label="Time">
            <input type="time" value={form.time} onChange={update('time')} className="input" />
          </Field>
        </div>

        <Field label="Notes (optional)">
          <div className="flex items-start gap-2">
            <textarea value={form.notes} onChange={update('notes')} rows={2} className="input" placeholder="Anything the doctor should know beforehand" />
            <VoiceInput onResult={(t) => setForm((f) => ({ ...f, notes: f.notes ? `${f.notes} ${t}` : t }))} />
          </div>
        </Field>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" className="w-full">Check availability &amp; book</Button>

        {suggestions && (
          <div className="rounded-card border border-warning/30 bg-warning/5 p-4">
            <p className="text-sm font-medium text-ink">That time isn't available.</p>
            {suggestions.length > 0 ? (
              <>
                <p className="mt-1 text-sm text-ink/60">Here are the nearest open times with the same doctor:</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {suggestions.map((slot) => (
                    <button
                      type="button"
                      key={slot.toISOString()}
                      onClick={() => bookSuggestedSlot(slot)}
                      className="rounded-md border border-line bg-paper px-3 py-2 text-sm hover:border-primary hover:text-primary"
                    >
                      {formatDateTime(slot)}
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <p className="mt-1 text-sm text-ink/60">No openings found in the next 10 days.</p>
            )}
            <Button type="button" variant="ghost" className="mt-3" onClick={handleWaitlist}>
              None of these work — join the waiting list instead
            </Button>
          </div>
        )}
      </form>
    </Card>
  )
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-ink/60">{label}</span>
      {children}
    </label>
  )
}
