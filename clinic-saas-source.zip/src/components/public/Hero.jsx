import { Link } from 'react-router-dom'
import { ArrowRight, CalendarCheck } from 'lucide-react'
import { useClinicData } from '../../context/DataContext'

export default function Hero() {
  const { clinic, doctors } = useClinicData()
  const lead = doctors[0]

  return (
    <section className="border-b border-line bg-paper">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-2 md:items-center md:py-24">
        <div>
          <p className="text-sm font-medium text-primary">{clinic.name} · {clinic.address.split(',')[1]?.trim() || 'Riverside'}</p>
          <h1 className="mt-3 font-display text-4xl leading-[1.1] text-ink md:text-5xl">
            Attentive care, on a schedule that respects your time.
          </h1>
          <p className="mt-5 max-w-md text-ink/70">
            {lead.fullName} and the {clinic.name} team combine thorough exams with a
            booking system that finds you the next real opening — no phone tag, no guesswork.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/book" className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-medium text-white hover:bg-primary-dark">
              <CalendarCheck className="h-4 w-4" /> Book Appointment
            </Link>
            <a href="#services" className="inline-flex items-center gap-2 rounded-md border border-line px-5 py-3 text-sm font-medium text-ink hover:bg-line/30">
              View Services <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/3] w-full rounded-card bg-primary-light" />
          <div className="absolute -bottom-6 -left-6 hidden rounded-card border border-line bg-paper p-4 shadow-sm sm:block">
            <p className="font-display text-2xl text-ink">4.9<span className="text-base text-ink/50">/5</span></p>
            <p className="text-xs text-ink/60">from recent patient reviews</p>
          </div>
        </div>
      </div>
    </section>
  )
}
