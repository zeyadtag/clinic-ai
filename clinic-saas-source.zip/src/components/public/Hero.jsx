import { Link } from 'react-router-dom'
import { ArrowRight, CalendarCheck, CheckCircle2, Clock3, ShieldCheck, Sparkles, Stethoscope } from 'lucide-react'
import { useClinicData } from '../../context/DataContext'

export default function Hero() {
  const { clinic, doctors } = useClinicData()
  const lead = doctors[0]

  return (
    <section id="home" className="relative scroll-mt-16 overflow-hidden border-b border-line bg-paper lg:scroll-mt-0">
      <div className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-primary-light/70 blur-3xl" />
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[1.02fr_.98fr] lg:items-center lg:px-8 lg:py-24">
        <div>
          <p className="inline-flex items-center gap-2 rounded-pill border border-primary/15 bg-primary-light/60 px-3 py-1.5 text-xs font-semibold uppercase tracking-[.14em] text-primary-dark">
            <Sparkles className="h-3.5 w-3.5" /> Modern care, thoughtfully delivered
          </p>
          <h1 className="mt-5 max-w-2xl font-display text-4xl leading-[1.06] text-ink sm:text-5xl lg:text-6xl">
            Better care starts with a clinic that feels prepared.
          </h1>
          <p className="mt-6 max-w-xl text-base leading-7 text-ink/65">
            {lead.fullName} and the {clinic.name} team combine thorough exams with a
            booking system that finds you the next real opening — no phone tag, no guesswork.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/book" className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-medium text-white hover:bg-primary-dark">
              <CalendarCheck className="h-4 w-4" /> Book Appointment
            </Link>
            <a href="#services" className="inline-flex items-center gap-2 rounded-md border border-line px-5 py-3 text-sm font-medium text-ink hover:bg-line/30">
              View Services <ArrowRight className="h-4 w-4" />
            </a>
          </div>
          <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-ink/60">
            <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-primary" /> Real-time availability</span>
            <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> Secure patient records</span>
          </div>
        </div>
        <div className="relative mx-auto w-full max-w-xl">
          <div className="overflow-hidden rounded-[28px] border border-primary/10 bg-gradient-to-br from-[#0f7569] via-[#155f59] to-[#173d3b] p-6 shadow-[0_28px_70px_rgba(18,69,64,.22)] sm:p-8">
            <div className="flex items-center justify-between text-white">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[.18em] text-white/55">Your next visit</p>
                <p className="mt-2 font-display text-2xl">Care without the wait</p>
              </div>
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10"><Stethoscope className="h-6 w-6" /></span>
            </div>
            <div className="mt-8 rounded-2xl border border-white/15 bg-white p-5 shadow-lg">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-primary">Confirmed</p>
                  <h3 className="mt-1 font-display text-xl text-ink">General consultation</h3>
                  <p className="mt-1 text-sm text-ink/55">with {lead.fullName}</p>
                </div>
                <span className="rounded-xl bg-primary-light p-3 text-primary"><CalendarCheck className="h-5 w-5" /></span>
              </div>
              <div className="mt-5 flex items-center justify-between rounded-xl bg-base px-4 py-3 text-sm">
                <span className="flex items-center gap-2 font-medium text-ink"><Clock3 className="h-4 w-4 text-primary" /> Today, 11:15 AM</span>
                <span className="text-ink/45">20 min</span>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/10 p-4 text-white"><p className="font-display text-2xl">4.9/5</p><p className="mt-1 text-xs text-white/60">Patient rating</p></div>
              <div className="rounded-2xl border border-white/10 bg-white/10 p-4 text-white"><p className="font-display text-2xl">23+ yrs</p><p className="mt-1 text-xs text-white/60">Combined experience</p></div>
            </div>
          </div>
          <div className="absolute -bottom-5 -left-4 hidden items-center gap-3 rounded-2xl border border-line bg-paper px-4 py-3 shadow-lg sm:flex">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-light text-primary"><CheckCircle2 className="h-5 w-5" /></span>
            <div><p className="text-sm font-semibold text-ink">Booking confirmed</p><p className="text-xs text-ink/50">Instantly, without a phone call</p></div>
          </div>
        </div>
      </div>
    </section>
  )
}
