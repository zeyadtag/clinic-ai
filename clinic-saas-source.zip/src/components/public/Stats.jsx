import { useClinicData } from '../../context/DataContext'

export default function Stats() {
  const { doctors, patients, reviews } = useClinicData()
  const avgRating = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : '—'
  const totalYears = doctors.reduce((s, d) => s + d.yearsExperience, 0)

  const stats = [
    { label: 'Patients treated', value: `${(patients.length * 340).toLocaleString()}+` },
    { label: 'Years of combined experience', value: `${totalYears}+` },
    { label: 'Average patient rating', value: `${avgRating} / 5` },
    { label: 'Successful visits this year', value: '2,180+' },
  ]

  return (
    <section className="border-b border-line bg-base">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-5 py-12 md:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label}>
            <p className="font-display text-3xl text-ink">{s.value}</p>
            <p className="mt-1 text-sm text-ink/60">{s.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
