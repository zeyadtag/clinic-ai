export default function Card({ children, className = '', padded = true }) {
  return (
    <div className={`rounded-card border border-line bg-paper ${padded ? 'p-5' : ''} ${className}`}>
      {children}
    </div>
  )
}
