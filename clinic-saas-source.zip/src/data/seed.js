import { uid } from '../utils/id'
import { addDays, addMinutes, startOfDay } from '../utils/dateHelpers'

// Synthetic demo fixtures only. These labels and contact details do not
// represent real people and must never be replaced with production records.

const today = startOfDay(new Date())

export function buildSeed() {
  const clinic = {
    id: 'clinic_meridian',
    name: 'Meridian Clinic',
    slug: 'meridian',
    timezone: 'America/New_York',
    phone: '(555) 019-2200',
    address: '48 Harbor View Ave, Suite 3, Riverside',
  }

  const doctors = [
    {
      id: 'doc_amara',
      fullName: 'Dr. Amara Chen',
      title: 'Family & Internal Medicine',
      specialties: ['Family Medicine', 'Preventive Care', 'Chronic Disease Management'],
      qualifications: ['MD, Johns Hopkins University', 'Board Certified, Internal Medicine'],
      yearsExperience: 14,
      bio: 'Dr. Chen has spent over a decade helping patients manage long-term health with a calm, thorough approach — she believes the best outcomes come from actually listening first.',
      slotDurationMinutes: 30,
      isActive: true,
    },
    {
      id: 'doc_ravi',
      fullName: 'Dr. Ravi Patel',
      title: 'Dermatology & Aesthetic Medicine',
      specialties: ['Dermatology', 'Acne Treatment', 'Cosmetic Procedures'],
      qualifications: ['MD, University of Michigan', 'Fellowship, Dermatologic Surgery'],
      yearsExperience: 9,
      bio: 'Dr. Patel combines clinical dermatology with aesthetic treatments, tracking every patient\u2019s progress carefully from first consult to final result.',
      slotDurationMinutes: 45,
      isActive: true,
    },
  ]

  const services = [
    { id: 'svc_checkup', name: 'General Checkup', description: 'Full physical exam and health review.', priceCents: 12000, durationMinutes: 30 },
    { id: 'svc_followup', name: 'Follow-up Visit', description: 'Short visit to review progress on an existing issue.', priceCents: 7000, durationMinutes: 20 },
    { id: 'svc_derm', name: 'Dermatology Consult', description: 'Skin assessment and treatment planning.', priceCents: 15000, durationMinutes: 45 },
    { id: 'svc_aesthetic', name: 'Aesthetic Treatment', description: 'Cosmetic procedure with before/after tracking.', priceCents: 32000, durationMinutes: 60 },
    { id: 'svc_bloodwork', name: 'Bloodwork Review', description: 'Lab result review and next steps.', priceCents: 9000, durationMinutes: 20 },
  ]

  const patients = [
    {
      id: 'pat_jordan',
      fullName: 'Demo Patient 01',
      phone: '000-000-0001',
      email: 'demo.patient01@example.invalid',
      dateOfBirth: '1990-01-01',
      gender: 'Male',
      allergies: ['Penicillin'],
      chronicConditions: ['Hypertension'],
      currentMedications: ['Lisinopril 10mg'],
      notes: 'Prefers early morning appointments.',
      loyaltyLevel: 'gold',
      totalVisits: 9,
      completedVisits: 8,
    },
    {
      id: 'pat_sofia',
      fullName: 'Demo Patient 02',
      phone: '000-000-0002',
      email: 'demo.patient02@example.invalid',
      dateOfBirth: '1990-01-01',
      gender: 'Female',
      allergies: [],
      chronicConditions: [],
      currentMedications: [],
      notes: '',
      loyaltyLevel: 'unlocked',
      totalVisits: 4,
      completedVisits: 4,
    },
    {
      id: 'pat_wei',
      fullName: 'Demo Patient 03',
      phone: '000-000-0003',
      email: 'demo.patient03@example.invalid',
      dateOfBirth: '1990-01-01',
      gender: 'Male',
      allergies: ['Sulfa drugs'],
      chronicConditions: ['Type 2 Diabetes'],
      currentMedications: ['Metformin 500mg'],
      notes: 'Needs interpreter assistance on occasion (Mandarin).',
      loyaltyLevel: 'vip',
      totalVisits: 16,
      completedVisits: 15,
    },
    {
      id: 'pat_amelia',
      fullName: 'Demo Patient 04',
      phone: '000-000-0004',
      email: 'demo.patient04@example.invalid',
      dateOfBirth: '1990-01-01',
      gender: 'Female',
      allergies: [],
      chronicConditions: [],
      currentMedications: [],
      notes: '',
      loyaltyLevel: 'new',
      totalVisits: 1,
      completedVisits: 0,
    },
  ]

  const mk = (h, m = 0, dayOffset = 0) => addMinutes(startOfDay(addDays(today, dayOffset)), h * 60 + m)

  const appointments = [
    { id: uid('appt'), patientId: 'pat_jordan', doctorId: 'doc_amara', serviceId: 'svc_checkup', startsAt: mk(9, 0), endsAt: mk(9, 30), status: 'completed' },
    { id: uid('appt'), patientId: 'pat_sofia', doctorId: 'doc_ravi', serviceId: 'svc_derm', startsAt: mk(9, 30), endsAt: mk(10, 15), status: 'completed' },
    { id: uid('appt'), patientId: 'pat_amelia', doctorId: 'doc_amara', serviceId: 'svc_checkup', startsAt: mk(10, 30), endsAt: mk(11, 0), status: 'in_progress' },
    { id: uid('appt'), patientId: 'pat_wei', doctorId: 'doc_amara', serviceId: 'svc_followup', startsAt: mk(11, 15), endsAt: mk(11, 35), status: 'confirmed' },
    { id: uid('appt'), patientId: 'pat_jordan', doctorId: 'doc_ravi', serviceId: 'svc_aesthetic', startsAt: mk(13, 0), endsAt: mk(14, 0), status: 'scheduled' },
    { id: uid('appt'), patientId: 'pat_sofia', doctorId: 'doc_amara', serviceId: 'svc_bloodwork', startsAt: mk(15, 0), endsAt: mk(15, 20), status: 'cancelled', cancellationReason: 'Patient rescheduled' },
    { id: uid('appt'), patientId: 'pat_wei', doctorId: 'doc_ravi', serviceId: 'svc_derm', startsAt: mk(9, 0, 1), endsAt: mk(9, 45, 1), status: 'scheduled' },
    { id: uid('appt'), patientId: 'pat_amelia', doctorId: 'doc_amara', serviceId: 'svc_checkup', startsAt: mk(10, 0, -1), endsAt: mk(10, 30, -1), status: 'no_show' },
  ]

  const visits = [
    {
      id: uid('visit'),
      patientId: 'pat_jordan',
      doctorId: 'doc_amara',
      serviceId: 'svc_checkup',
      visitDate: mk(9, 0, -7),
      diagnosis: 'Well-controlled hypertension',
      treatment: 'Continue Lisinopril 10mg daily',
      doctorNotes: 'BP 128/82, patient reports consistent medication adherence.',
      followUpDate: null,
      status: 'completed',
    },
    {
      id: uid('visit'),
      patientId: 'pat_wei',
      doctorId: 'doc_amara',
      serviceId: 'svc_followup',
      visitDate: mk(11, 0, -14),
      diagnosis: 'Type 2 diabetes, stable',
      treatment: 'Continue Metformin, dietary counseling reinforced',
      doctorNotes: 'A1C trending down since last visit. Encouraged to continue current routine.',
      followUpDate: null,
      status: 'completed',
    },
    {
      id: uid('visit'),
      patientId: 'pat_sofia',
      doctorId: 'doc_ravi',
      serviceId: 'svc_derm',
      visitDate: mk(9, 30, 0),
      diagnosis: 'Mild eczema, forearms',
      treatment: 'Topical corticosteroid, twice daily for 2 weeks',
      doctorNotes: 'No signs of infection. Advised fragrance-free moisturizer.',
      followUpDate: addDays(today, 14).toISOString().slice(0, 10),
      status: 'completed',
    },
  ]

  const treatments = [
    {
      id: uid('tx'),
      patientId: 'pat_sofia',
      medication: 'Hydrocortisone 1% cream',
      instructions: 'Apply a thin layer to affected areas twice daily.',
      startDate: today.toISOString().slice(0, 10),
      endDate: addDays(today, 14).toISOString().slice(0, 10),
      reminderSchedule: 'daily_08:00,daily_20:00',
      isActive: true,
    },
  ]

  const waitingList = [
    { id: uid('wl'), patientId: 'pat_amelia', serviceId: 'svc_derm', doctorId: 'doc_ravi', preferredStart: mk(9, 0, 2), status: 'open' },
  ]

  const followups = [
    {
      id: uid('fu'),
      patientId: 'pat_wei',
      visitId: visits[1].id,
      kind: 'clinical',
      status: 'pending',
      scheduledFor: addDays(today, -1),
      response: null,
      flagged: false,
    },
  ]

  const reviews = [
    { id: uid('rev'), patientId: 'pat_jordan', rating: 5, sentiment: 'positive', comment: 'Dr. Chen always takes time to explain everything clearly.', isPublic: true },
    { id: uid('rev'), patientId: 'pat_wei', rating: 5, sentiment: 'positive', comment: 'Front desk is efficient and the wait times are short.', isPublic: true },
    { id: uid('rev'), patientId: 'pat_sofia', rating: 4, sentiment: 'positive', comment: 'Great results from my dermatology treatment plan.', isPublic: true },
  ]

  const rewards = [
    { id: uid('rw'), patientId: 'pat_wei', milestoneVisits: 10, rewardDescription: '10% off next visit', grantedAt: addDays(today, -40) },
  ]

  const notifications = []
  const dayStatus = {
    doc_amara: { runningLateMinutes: 8, patientsAhead: 1 },
    doc_ravi: { runningLateMinutes: 0, patientsAhead: 0 },
  }

  return { clinic, doctors, services, patients, appointments, visits, treatments, waitingList, followups, reviews, rewards, notifications, dayStatus }
}
