import BookingForm from '../../components/public/BookingForm'

export default function BookAppointmentPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <div className="mx-auto mb-10 max-w-xl text-center">
        <h1 className="font-display text-3xl text-ink">Book an appointment</h1>
        <p className="mt-2 text-ink/60">Pick a service and doctor — we'll check real availability instantly.</p>
      </div>
      <BookingForm />
    </section>
  )
}
