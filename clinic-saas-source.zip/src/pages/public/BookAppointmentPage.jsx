import BookingForm from '../../components/public/BookingForm'

export default function BookAppointmentPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <div className="mx-auto mb-10 max-w-xl text-center">
        <h1 className="font-display text-3xl font-bold text-ink">احجز موعدك</h1>
        <p className="mt-2 text-ink/60">اختر الخدمة والطبيب وسنتحقق من المواعيد المتاحة فورًا.</p>
      </div>
      <BookingForm />
    </section>
  )
}
