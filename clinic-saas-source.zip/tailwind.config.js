/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#12242E',
        base: '#F7F8F6',
        paper: '#FFFFFF',
        line: '#DFE3E0',
        primary: {
          DEFAULT: '#0F6E63',
          light: '#DCEEEA',
          dark: '#0A4A42'
        },
        accent: {
          DEFAULT: '#E4633F',
          light: '#FBE4DA'
        },
        success: '#2F855A',
        warning: '#B7791F',
        danger: '#C0392B'
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif']
      },
      borderRadius: {
        card: '10px',
        pill: '999px'
      }
    }
  },
  plugins: []
}
