/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#E8EEF7',
        base: '#07111F',
        paper: '#0C192C',
        line: '#1D2C43',
        primary: {
          DEFAULT: '#5B8CFF',
          light: '#142B4D',
          dark: '#8DB3FF'
        },
        accent: {
          DEFAULT: '#F59E6F',
          light: '#3B2630'
        },
        success: '#2F855A',
        warning: '#B7791F',
        danger: '#C0392B'
      },
      fontFamily: {
        display: ['"Inter"', 'system-ui', 'sans-serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif']
      },
      borderRadius: {
        card: '16px',
        pill: '999px'
      }
    }
  },
  plugins: []
}
